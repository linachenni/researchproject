import java.awt.Point;

public class MatriceInt {
    private char nom;
    private int taille;
    private int[][] matrice;
    char[][] mString;
    private Point pos=new Point();
    public MatriceInt(char n, int t, char[][] mS){
        nom=n;
        taille=t;
        matrice=new int[taille][taille];
        for(int i=0; i<mS.length; i++){
            for(int j=0; j<mS.length; j++)
                if(mS[i][j]==nom){
                    pos.setLocation(j, i);
                    break;
                }
            if(pos.getX()!=0)
                break;    
        }
    }
    public char getNom(){
        return nom;
    }
    public int getTaille(){
        return taille;
    }
    public int[][] getMatrice(){
        return matrice;
    }
    public void mettreEnInt(char[][] c){
        for (int i=0; i<matrice.length; i++) {
            for(int j=0; j<matrice.length; j++){
                switch (c[i][j]){
                    case '#':
                        matrice[i][j]=1;
                        break;
                    case 'A':
                        matrice[i][j]=2;
                        break;
                    case '$':
                        matrice[i][j]=8;
                        break;
                    case '+':
                        matrice[i][j]=2;
                        matrice[i][j]+=4;
                        break;
                    case '*':
                        matrice[i][j]=8;
                        matrice[i][j]+=4;
                        break;
                    case '@':
                        matrice[i][j]=4;
                        break;
                    case ':':
                        matrice[i][j]=5;
                        break;
                    case ' ':
                        matrice[i][j]=0;
                        break;
                    default:
                        matrice[i][j]=9;
                        break;
                }
            }
        }
    }
    @Override
    public String toString() {
        String m=pos.getX()+" "+pos.getY()+'\n';
        m+=nom+" "+taille+'\n';
        for(int i=0; i<matrice.length; i++){
            for(int j=0; j<matrice[0].length; j++)
                m+=matrice[i][j];
            m+='\n';
        }
        return m;
    }
}
