import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;

public class Titre extends JLabel{
    public Titre(String titre, String font){
        super(titre, JLabel.CENTER);
        Font customFont = null;
        try {
                customFont = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("/fonts/"+font));
        } catch (Exception e) {
            e.printStackTrace();
        }
        setFont(customFont.deriveFont(Font.BOLD, 60));
        setPreferredSize(new Dimension(150,150));
        setOpaque(false);
        setForeground(Color.white);
    }
}
