import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class LevelLector {
	Scanner input;
    Level level_1 = new Level();
    ArrayList<Matrice> Mat=new ArrayList<Matrice>();
    public LevelLector(InputStream in){
        input = new Scanner(in);
        readNextLevel();
    }
    public void readNextLevel(){
    	String lecture = null;
        int i=0;
        lecture=read();
        while(lecture!=null){
            if(lecture.length()>1 && Character.isDigit(lecture.charAt(2))){
                String t=""+lecture.charAt(2);
                if(lecture.length()==4)
                    t+=lecture.charAt(3);
                Mat.add(new Matrice());
                Mat.get(Mat.size()-1).setNom(lecture.charAt(0));
                Mat.get(Mat.size()-1).setTaille(Integer.parseInt(t));
                i=-1;
            }
            else{
                for(int j = 0; j < lecture.length(); j++)
                    Mat.get(Mat.size()-1).initMatrice(i, j, lecture.charAt(j));
            }
            lecture=read();
            i++;
            if(i==Mat.get(Mat.size()-1).getMatrice().length)
                lecture=read();
        }
    }
    public String read(){
        String l;
        try{
            l = input.nextLine();
        }catch (Exception e){
            return null;
        }
        return l;
    }
    public ArrayList<MatriceInt> getFichInt(){
        ArrayList<MatriceInt> mI =new ArrayList<MatriceInt>();
        for(Matrice m : Mat){
            mI.add(new MatriceInt(m.getNom(), m.getTaille(), Mat.get(0).getMatrice()));
            mI.get(mI.size()-1).mettreEnInt(m.getMatrice());
        }
        return mI;
    }
    public ArrayList<Matrice> getFich(){
        return Mat;
    }
    public static void main(String[] args) {
        LevelLector l=null;
        try {
            l=new LevelLector(Configuration.charge("../niveauxDuJeu/niveau9.txt"));
        } catch (FileNotFoundException e) {
            System.out.println(e);
        }
        System.out.println(l.Mat.get(0));
        System.out.println(l.Mat.get(1));
        System.out.println(l.getFichInt().get(0));
        System.out.println(l.getFichInt().get(1));
    }
}