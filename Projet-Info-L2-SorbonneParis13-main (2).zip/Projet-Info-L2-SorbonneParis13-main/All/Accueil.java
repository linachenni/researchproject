import java.awt.BorderLayout;

import javax.swing.JPanel;

public class Accueil extends Bouton{
    public Accueil(Fenêtrage c){
        super("CONTINUER", c);
        c.add(contenu(), "accueil");
        addActionListener(e->c.show("accueil")); 
    }
    public JPanel contenu(){
        PanneauBouton LesBoutons;
        Background background=new Background("BG2.png", "PATRICK'S PARABOX");
        LesBoutons=new PanneauBouton(card);
        background.add(LesBoutons, BorderLayout.CENTER);
        return background;
    }
}