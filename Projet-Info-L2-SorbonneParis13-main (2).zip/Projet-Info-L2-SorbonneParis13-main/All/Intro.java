import java.awt.BorderLayout;
import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JPanel;

public class Intro extends JPanel {
    public Intro(Fenêtrage card){
        super();
        Background back=new Background("BG2.png", "PATRICK'S PARABOX");
        card.add(back);
        back.add(new Accueil(card), BorderLayout.SOUTH);
        JEditorPane contenu=new JEditorPane();
        try {
            contenu.setPage("file:Patrick's.html");
        } catch (IOException e) {
            System.out.println(e);
        }
        contenu.setOpaque(false);
        back.add(contenu, BorderLayout.CENTER);
    }
}
