import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import javax.swing.JPanel;

/*le jeu est composé de trois types de boites :
 * les boites monde 
 * la boite du joueur qui est unique pour chaque niveau
 * et la boite simple à déplacer
 * cette classe définit une boite simple
 * elle prend en @param :
 * la couleur de la boîte
 * ses coordonnées X et Y dans le jeu
 * et le niveau dans lequel la boîte va agir.
 * 
 * La classe BoxMonde qui définit les miniMonde
 * et la classe HeadBox qui définit le joueur
 * héritent tous de Box car au delà des yeux du joueur et la particularité de contenir un mini monde de Box Monde
 * ce sont des boîtes tout simplement les attributs essentiels de Box sont aussi essentiels pour 
 * HeadBox et BoxMonde tel que les coordonnées
 * 
*/

public class Box extends JPanel{
    // attributs essentiels : couleur, coordonnée, taille de la boîte
    private Color color;
    private int X, Y;
    private Niveau niveau;
    private int sizeBox=80;
    private ArrayList<String> historique=new ArrayList<String>();
    //constructeur : couleur, coordonnées (x, y) et le niveau opérant
    //les coordonnées seront mis à l'échelle
    //1 case -> sizeBox
    //du coup x=1 donné en paramêtre signifie que la coordonnée de la boîte est de 80
    public Box(Color c, int x, int y, Niveau n){
        super(); // JPanel
        setOpaque(false); //pour masquer le JPanel, elle sera redessiné
        X=x*sizeBox; Y=y*sizeBox;
        color=c;
        niveau=n;
    }

    /*les déplacements
     * Dans une interface graphique quelconque le point de coordonnée (historique.size()-1,historique.size()-1) qu'on peut peut appelé référence
     * correspond au somment se trouvant en haut à gauche de la fenêtre
     * voici une fenêtre :
     *                Point(0,0)
     *                    \_ .____________
     *                       |------------|
     *                       |            |
     *                       |            |
     *                       |            |
     *                       |____________|
     * 
     * donc pour un déplacement en bas, Y augmente de sizeBox,
     * ''                    '' en haut, Y diminue de sizeBox,
     * ''                    '' à gauche, X diminue de sizeBox,
     * ''                    '' à droit, X augmente de sizeBox,
     * A chaque fois qu'il ya un mouvement les coordonnées sont mis à jour, c'est ce qui engendre le déplacement
     * 
    */
    
    public void moveUp(){
        Y-=getSizeBox();
        historique.add("up");   
    }
    public void moveDown(){
        Y+=getSizeBox();
        historique.add("down");
    }
    public void moveLeft(){
        X-=getSizeBox();
        historique.add("left");
    }
    public void moveRight(){
        X+=getSizeBox();
        historique.add("right");
    }
    public String getStory(){
        return historique.get(historique.size()-1);
    }
    /*méthode dessine le carré avec les coordonnées et la couleur spécifié
     * elle sera utilisé dans la redéfinition du PaintComponent du niveau concerné
     * zoomX et zoomY sont des paramêtres qui serviront au ZOOM de la BoxMonde
     * drawRect dessine un carré sans fond, elle ne représente que des bordures
     * fillRect dessine un carré et lui donne une couleur de fond, celle spécifiée
     */
    public void paintBox(Graphics arg, int posX, int posY){
        Graphics2D arg0=(Graphics2D)arg;
        int zoomX, zoomY;
        if(getNiveau().getBoxMonde()==null){
            zoomX=0;
            zoomY=0;
        }
        else{
            zoomX=getNiveau().getBoxMonde().zoomX;
            zoomY=getNiveau().getBoxMonde().zoomX;
        }
        arg0.setStroke(new BasicStroke(4));
        arg0.setColor(Color.black);
        arg0.drawRect(zoomX+(posX*getSizeBox()), zoomY+(posY*getSizeBox()), getSizeBox(),getSizeBox());
        arg0.setColor(color);
        arg0.fillRect(zoomX+(posX*getSizeBox()), zoomY+(posY*getSizeBox()), getSizeBox(),getSizeBox());
    }
    //des getters, ça peut être utile
    public Color getColor(){
        return color;
    }
    public int getX(){
        return X;
    }
    public int getY(){
        return Y;
    }
    public void setX(int x){
        X=x;
    }
    public void setY(int y){
        Y=y;
    }
    public Niveau getNiveau(){
        return niveau;
    }
    public int getSizeBox(){
        return sizeBox;
    }
    public ArrayList<String> Historique(){
        return historique;    
    }
    public void move(String c){
        switch(c){
            case "up": case "Up": case "UP":
                moveUp();
                break;
            case "down": case "Down": case "DOWN":
                moveDown();
                break;
            case "left": case "Left": case "LEFT":
                moveLeft();
                break;
            case "right": case "Right": case "RIGHT":
                moveRight();
                break;
            default:
                System.out.println("mouvement inconnue");
                break;
        }
    }
    public void setLocation(int x, int y){
        X=x*sizeBox;
        Y=y*sizeBox;
    }
    //méthode pour modifier la taille d'une boîte
    //utile lors du zoom
    public void setSizeBox(int newSize){
        X/=sizeBox;
        Y/=sizeBox;
        sizeBox=newSize;
        X*=sizeBox;
        Y*=sizeBox;
    }
    //méthode pour modifier et la taille et les coordonnées
    //utile pour le changement de monde
    public void setSizeAndLocationBox(int s, int x, int y){
        sizeBox=s;
        X=x;
        Y=y;
    }
}
