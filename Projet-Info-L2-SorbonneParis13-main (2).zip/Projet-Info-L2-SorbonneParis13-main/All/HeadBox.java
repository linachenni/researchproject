import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics; 
import java.awt.Graphics2D;

public class HeadBox extends Box{
    Niveau niveau;                              
    public HeadBox(Color c, int x, int y, Niveau niveau){
        super(c, x, y, niveau);
        this.niveau=niveau;
    }
    public void paintHeadBox(Graphics arg){
        Graphics2D arg0=(Graphics2D)arg;
        int zoomX, zoomY;
        if(getNiveau().getBoxMonde()==null){
            zoomX=0;
            zoomY=0;
        }
        else{
            zoomX=getNiveau().getBoxMonde().zoomX;
            zoomY=getNiveau().getBoxMonde().zoomX;
        }
        arg0.setStroke(new BasicStroke(4));
        arg0.setColor(Color.black);
        arg0.drawRect(zoomX+getX(),zoomY+getY(),getSizeBox(),getSizeBox());
        arg0.setColor(getColor());
        arg0.fillRect(zoomX+getX(),zoomY+getY(),getSizeBox(),getSizeBox());
        arg0.setColor(Color.darkGray);
        arg0.fillOval(zoomX+getX()+20,zoomY+getY()+20,20,20);
        arg0.fillOval(zoomX+getX()+55,zoomY+getY()+20,20,20);
    }
    public void cancelUp(){
        setY(getY()+getSizeBox());
        getNiveau().getJeu().move(1,0);
        Historique().remove(Historique().size()-1);
    }
    public void cancelDown(){
        setY(getY()-getSizeBox());
        getNiveau().getJeu().move(-1,0);
        Historique().remove(Historique().size()-1);
    }
    public void cancelLeft(){
        setX(getX()+getSizeBox());
        getNiveau().getJeu().move(0,1);
        Historique().remove(Historique().size()-1);
    }
    public void cancelRight(){
        setX(getX()-getSizeBox());
        getNiveau().getJeu().move(0,-1);
        Historique().remove(Historique().size()-1);
    }
    public void cancel(){
        switch(getStory()){
            case "up":
                cancelUp();
                break;
            case "down":
                cancelDown();
                break;
            case "left":
                cancelLeft();
                break;
            case "right":
                cancelRight();
                break;
            default:
                break;
        }
    }
}

/*if(b.getX()==boxes[1].getX() && b.getY()==boxes[1].getY()){
        b.setSizeAndLocationBox(niveau.getBoxMonde().getSizeBoxMiniMonde(), niveau.getBoxMonde().getX()-niveau.getBoxMonde().zoomX, niveau.getBoxMonde().getY()-niveau.getBoxMonde().zoomY);
    }
    if(getThis().getX()==boxes[1].getX() && getThis().getY()==boxes[1].getY()){
        ((BoxMonde)boxes[1]).zoom();
        getThis().setSizeAndLocationBox(niveau.getBoxMonde().getSizeBoxMiniMonde(), niveau.getBoxMonde().getX()-niveau.getBoxMonde().zoomX, niveau.getBoxMonde().getY()-niveau.getBoxMonde().zoomY);
    }
*/