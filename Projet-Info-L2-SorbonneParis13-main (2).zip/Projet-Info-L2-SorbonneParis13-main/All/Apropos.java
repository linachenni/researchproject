import javax.swing.JPanel;

public class Apropos extends Bouton{
    public Apropos(Fenêtrage c){
        super("RULES", c);
        c.add(contenu(), "apropos");
        addActionListener(e->c.show("apropos"));
    }
    public JPanel contenu(){
        Background back=new Background("BG2.png", "A  P R O P O S");
        return back;
    }
}
