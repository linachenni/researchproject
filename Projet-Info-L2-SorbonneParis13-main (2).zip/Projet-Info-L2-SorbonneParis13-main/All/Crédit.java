import java.awt.BorderLayout;
//import java.io.IOException;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Crédit extends Bouton{
    public Crédit(Fenêtrage c){
        super("CREDITS", c);
        c.add(contenuCrédit(), "crédit");
        addActionListener(e->c.show("crédit"));
    }
    public JPanel contenuCrédit(){
        Background back=new Background("BG2.png", "C R E D I T S");
        JScrollPane scroll=new JScrollPane(back);
        JPanel pan=new JPanel(new BorderLayout());
        Retour retour=new Retour(getCard());
        JEditorPane contenu=new JEditorPane();
        /*try {
            contenu.setPage("file:Text.html");
        } catch (IOException e) {
            System.out.println(e);
        }*/
        contenu.setOpaque(false);
        back.add(contenu, BorderLayout.CENTER);
        pan.add(scroll, BorderLayout.CENTER);
        pan.add(retour, BorderLayout.SOUTH);
        pan.setOpaque(false);
        return pan;
    }
}
