import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;

public class Bouton extends JButton{
    Fenêtrage card;
    public Bouton(String name, Fenêtrage c){
        super(name);
        card=c;
        Font customFont = null;
        try {
                customFont = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("/fonts/chintzy.ttf"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        setBackground(new Color(16,48,92));
        setFont(customFont.deriveFont(Font.BOLD, 40));
        setForeground(Color.white);
    }
    public Bouton(String name, String cheminFont, Color couleurDeFond, Color couleurDuTexte){
        super(name);
        if(cheminFont!=null){
            Font customFont = null;
            try {
                    customFont = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream(cheminFont));
            } catch (Exception e) {
                e.printStackTrace();
            }
            setFont(customFont.deriveFont(Font.BOLD, 40));
        }
        setBackground(couleurDeFond);
        setForeground(couleurDuTexte);
    }
    /*public void mettreEnFenêtre(JPanel p){
        JFrame fen=new JFrame("fenêtre");
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setSize(720,760);
        fen.getContentPane().add(p);
        fen.setVisible(true);
    }*/
    public Fenêtrage getCard(){
        return card;
    }
}
