import java.io.OutputStream;
import java.io.PrintStream;

public class LevelPrinter {
	PrintStream printlevel;
	
    public LevelPrinter(OutputStream out){
        printlevel = new PrintStream(out);
    }

    public void printLevel(Level level){
        for(int i = 0; i < level.lines(); i++){
            int last = -1 ;
            for(int j = 0; j < level.columns(); j++)
                if(!level.isEmpty(i, j))
                    last = j;

            for(int j = 0; j < level.columns(); j++){
                if(level.hasWall(i, j))
                    printlevel.print('#');
                else if (level.hasPlayer(i, j))
                    if(level.hasTarget(i, j))
                        printlevel.print('+');
                    else
                        printlevel.print('@');
                else if (level.hasBox(i, j))
                    if(level.hasTarget(i, j))
                        printlevel.print('*');
                    else
                        printlevel.print('$');
                else if(level.hasTarget(i, j))
                    printlevel.print('.');
                else
                    printlevel.print(' ');
            }
            printlevel.println();
        }
        printlevel.println("; " + level.name());
        printlevel.println();
    }
}
