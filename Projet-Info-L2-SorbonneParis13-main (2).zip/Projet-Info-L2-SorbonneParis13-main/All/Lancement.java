import java.awt.Dimension;

import javax.swing.JFrame;

public class Lancement extends JFrame{
    Fenêtrage card=new Fenêtrage();
    public Lancement(){
        super("Patrick's Parabox");
        card.add(new Intro(card));
        getContentPane().add(card);
        setSize(new Dimension(720,760));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new Lancement();
    }
}