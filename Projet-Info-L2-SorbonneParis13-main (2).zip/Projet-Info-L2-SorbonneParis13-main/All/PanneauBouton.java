import javax.swing.JPanel;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;

public class PanneauBouton extends JPanel{
    public PanneauBouton(Fenêtrage c){
        super();
        setLayout(new GridLayout(4,1,10,10));
        setBackground(Color.white);
        setBorder(BorderFactory.createEmptyBorder(10, 200, 10, 200));
        add(new Start(c));
        add(new Rules(c));
        add(new Option(c));
        add(new Crédit(c));
        setOpaque(false);
    }
}
