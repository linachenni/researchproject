# Projet-Info-L2-SorbonneParis13
Notre projet consiste à implémenter notre propre version d’un Sokoban, vieux jeux-vidéo de puzzle où l’on doit pousser des boites au bon endroit. Une version bien améliorée avec l’idée de pouvoir entrer dans les boites et d’avoir des boites récursives. Langage Le projet est en Java + Swing (bibliothèque graphique de Java).
