import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

//classe BoxMonde qui hérite de Box et de ses attributs
public class BoxMonde extends Box{
    private Color Wall;
    private int sizeBoxMiniMonde=16;
    int oldX, oldY, oldSize;
    int zoomX=0;
    int zoomY=0;
    boolean oldAlreadySaved=false;
    public BoxMonde(Color back, Color wall, int x, int y, Niveau niveau){
        super(back,x,y,niveau);
        Wall=wall;
        oldX=getX(); oldY=getY(); oldSize=getSizeBox();
    }
    public void paintBoxMonde(Graphics arg, int[][] m){
        Graphics2D arg0=(Graphics2D)arg;
        arg0.setStroke(new BasicStroke(4));
        arg0.setColor(Color.black);
        arg0.drawRect(getX(), getY(), getSizeBox(),getSizeBox());
        arg0.setColor(getColor());
        arg0.fillRect(getX(), getY(), getSizeBox(),getSizeBox());
        Brique brique=new Brique(getNiveau());
        for(int i=0; i<m.length; i++){
            for(int j=0; j<m.length; j++){
                if(m[i][j]==1)
                    brique.paintMiniBrique(arg, j*sizeBoxMiniMonde, i*sizeBoxMiniMonde);
            }
        }
    }
    public void zoom(){
        if(!oldAlreadySaved){
            oldX=getX(); oldY=getY(); oldSize=getSizeBox();
            oldAlreadySaved=true;
        }
        for(Box b : getNiveau().boxes)
            b.setSizeBox(500);
        getNiveau().getBoxMonde().setSizeBox(500);
        getNiveau().getHeadBox().setSizeBox(500);
        zoomX=80-getX();
        zoomY=80-getY();
        sizeBoxMiniMonde=100;
        setX(80);
        setY(80);
        getNiveau().repaint();
    }
    public void unzoom(){
        for(Box b : getNiveau().boxes)
            b.setSizeBox(oldSize);
        getNiveau().getBoxMonde().setSizeBox(oldSize);
        getNiveau().getHeadBox().setSizeBox(oldSize);
        setX(oldX);
        setY(oldY);
        zoomX=0;
        zoomY=0;
        sizeBoxMiniMonde=16;
        getNiveau().repaint();
        oldAlreadySaved=false;
    }
    public Color getColorWall(){
        return Wall;
    }
    public int getSizeBoxMiniMonde(){
        return sizeBoxMiniMonde;
    }
}