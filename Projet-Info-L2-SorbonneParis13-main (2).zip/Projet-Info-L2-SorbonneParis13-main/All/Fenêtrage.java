import java.awt.CardLayout;
import javax.swing.JPanel;

public class Fenêtrage extends JPanel {
    private CardLayout card=new CardLayout();
    public Fenêtrage(){
        super();
        setLayout(card);
    }
    public void show(String s){
        card.show(this, s);
    }
    public void first(){
        card.show(this, "accueil");
    }
    public JPanel getCard(){
        return this;
    }
}
