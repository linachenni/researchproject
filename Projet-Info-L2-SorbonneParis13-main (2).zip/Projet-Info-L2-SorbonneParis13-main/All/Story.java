public class Story {
    private int time=0;
    private String move;
    public Story(String m, int t){
        move=m;
        time=t;
    }
    public int getTime(){
        return time;
    }
    public String getMove(){
        return move;
    }
    public void removeMove(){
        move=null;
    }
}
