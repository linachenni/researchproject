import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;

public class Brique extends JPanel {
    Color color;
    Niveau niveau;
    public Brique(Color c, Niveau n){
        super();
        color=c;
        niveau=n;
        
    }
    public Brique(Niveau n){
        super();
        niveau=n;
    }
    public void paintBrique(Graphics arg0, int X, int Y) {
        int zoomX, zoomY, size;
        if(niveau.getBoxMonde()==null){
            zoomX=0;
            zoomY=0;
            size=80;
        }
        else{
            zoomX=niveau.getBoxMonde().zoomX;
            zoomY=niveau.getBoxMonde().zoomY;
            size=niveau.getBoxMonde().getSizeBox();
        }
        arg0.setColor(color);
        arg0.fillRect(zoomX+(X*size),zoomY+(Y*size),size,size);
    }
    public void paintMiniBrique(Graphics arg0, int X, int Y) {
        if(niveau.getBoxMonde()==null)
            return;
        setBackground(niveau.getBoxMonde().getColor());
        int size=niveau.getBoxMonde().getSizeBoxMiniMonde();
        arg0.setColor(niveau.getBoxMonde().getColorWall());
        arg0.fillRect(niveau.getBoxMonde().getX()+X,niveau.getBoxMonde().getY()+Y,size,size);
    }
}
