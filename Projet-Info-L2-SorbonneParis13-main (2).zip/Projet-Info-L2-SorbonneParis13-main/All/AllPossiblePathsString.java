import java.util.*;
import java.awt.Point;

public class AllPossiblePathsString {
    public static List<List<String>> parcoursLargeur(boolean[][] M, int x1, int y1, int x2, int y2) {
        int n = M.length;
        Queue<List<String>> F = new LinkedList<>();
        Set<Point> V = new HashSet<>();
        List<List<String>> chemins = new ArrayList<>();
        List<String> cheminInitial = new ArrayList<>();
        cheminInitial.add(""); // Chemin initial vide
        F.offer(cheminInitial);
        while (!F.isEmpty()) {
            List<String> cheminCourant = F.poll(); // Retire et renvoie le premier élément de la file
            Point tete = getPositionFinale(x1, y1, cheminCourant); // Récupère la position finale du chemin

            if (tete.getX() == x2 && tete.getY() == y2) {
                // Si cette condition est remplie, on a trouvé un chemin, on le garde dans notre structure de données
                chemins.add(cheminCourant);
                continue; // On arrête l'itération en cours pour passer à la suivante
            }

            if (tete.getX() < 0 || tete.getX() >= n || tete.getY() < 0 || tete.getY() >= n) {
                // Test pour ne pas sortir de la matrice
                continue; // On arrête l'exécution dans la boucle et on passe à l'itération suivante
            }

            if (!M[(int)tete.getX()][(int)tete.getY()]) {
                // S'il y a un obstacle (case contient false), on continue sans explorer cette case
                continue;
            }

            if (V.contains(tete)) {
                // Si le point a déjà été visité, on continue sans explorer cette case
                continue;
            }

            V.add(tete); // On ajoute la case qu'on vient de parcourir dans l'ensemble des coordonnées déjà parcourues

            // On crée 4 copies "clone" du chemin courant
            List<String> copie1 = new ArrayList<>(cheminCourant);
            List<String> copie2 = new ArrayList<>(cheminCourant);
            List<String> copie3 = new ArrayList<>(cheminCourant);
            List<String> copie4 = new ArrayList<>(cheminCourant);

            // Chaque copie explore une possibilité
            copie1.add("right"); // Une liste vers la droite
            copie2.add("left"); // Une autre vers la gauche
            copie3.add("down"); // Encore une autre vers le bas
            copie4.add("up"); // Enfin une autre vers le haut

            // On ajoute ces possibilités à la file. En itérant avec les instructions du début, on ne sélectionnera que les chemins possibles
            F.offer(copie1);
            F.offer(copie2);
            F.offer(copie3);
            F.offer(copie4);
        }

        return chemins; // On retourne l'ensemble des chemins possibles
    }

    private static Point getPositionFinale(int x, int y, List<String> chemin) {
        Point position = new Point(x, y);
        for (String direction : chemin) {
            switch (direction) {
                case "right":
                    position.x += 1;
                    break;
                case "left":
                    position.x -= 1;
                    break;
                case "down":
                    position.y += 1;
                    break;
                case "up":
                    position.y -= 1;
                    break;
                default:
                    break;
            }
        }
        return position;
    }
}
