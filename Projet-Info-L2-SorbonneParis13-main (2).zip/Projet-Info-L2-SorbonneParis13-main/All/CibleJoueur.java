import java.awt.Color;
import java.awt.Graphics;

public class CibleJoueur extends Cible {
    Color color;
    Niveau niveau;
    public CibleJoueur(Color c, Niveau n){
        super(c,n);
        niveau=n;
    }
    public void paintCibleJoueur(Graphics arg0, int X, int Y){
        int zoomX, zoomY;
        int size;
        if(niveau.getBoxMonde()==null){
            zoomX=0;
            zoomY=0;
            size=80;
        }
        else{
            zoomX=niveau.getBoxMonde().zoomX;
            zoomY=niveau.getBoxMonde().zoomX;
            size=niveau.getBoxMonde().getSizeBox();
        }
        paintCible(arg0, X, Y);
        arg0.fillOval(zoomX+(X*size)+8, zoomY+(Y*size)+25, 17, 17);
        arg0.fillOval(zoomX+(X*size)+48, zoomY+(Y*size)+25, 17, 17);
    }
}
