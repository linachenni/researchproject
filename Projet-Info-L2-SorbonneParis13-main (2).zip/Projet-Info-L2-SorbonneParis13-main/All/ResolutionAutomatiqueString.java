import java.util.*;

public class ResolutionAutomatiqueString {
    public static List<String> trouverCheminPlusCourt(boolean[][] jeu, int x1, int y1, int x2, int y2) {
        List<List<String>> chemins = AllPossiblePathsString.parcoursLargeur(jeu, x1, y1, x2, y2);

        if (chemins.isEmpty()) {
            System.out.println("chemin null");
            return null; // Aucun chemin trouvé
        }

        List<String> cheminPlusCourt = chemins.get(0);
        for (List<String> chemin : chemins) {
            if (chemin.size() < cheminPlusCourt.size()) {
                cheminPlusCourt = chemin;
            }
        }

        return corrigerLeChemin(cheminPlusCourt);
    }
    /*
     * on s'est rendu compte que le chemin qui était retourné n'était pas tout à fait correct
     * mais que si on remplaçait left par down, right par up et vice versa dans le chemin retourné
     * et qu'on inversait la liste le chemin était correct
     * on s'est dit qu'il s'agit peut-être d'un problème du au fait que le système de plan dans
     * une matrice était différent que dans une interface, en effet la position (2,7) dans une interface
     * est différent de la position (2,7) de sa matrice, elle correspond plutôt à (7,2) dans la matrice
     * alors on s'est dit au lieu de chercher à réajuster les x et les y 
     * on va simplement inverser le tout
     */
    private static List<String> corrigerLeChemin(List<String> chemin){
        List<String> inverse = new ArrayList<>();
        for(int i=0; i<chemin.size(); i++){
            switch (chemin.get(chemin.size()-i-1)) {
                case "up":
                    inverse.add("right");
                    break;
                case "down":
                    inverse.add("left");
                    break;
                case "left":
                    inverse.add("down");
                    break;
                case "right":
                    inverse.add("up");
                    break;
                default:
                    break;
            }
        }
        return inverse;
    }
    public static void main(String[] args) {
        boolean[][] M= new boolean[][]{{false, false, false,false},
                                        {false,true,true,false},
                                        {false,true,false,false},
                                        {false,false,false,false}};
        List<String> lst=ResolutionAutomatiqueString.trouverCheminPlusCourt(M, 1, 2, 2, 1);
        for(String e : lst)
            System.out.println(e);
    }
}

