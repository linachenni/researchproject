public class Start extends Bouton{
    public Start(Fenêtrage c){
        super("START", c);
        c.add(new GraphicLevel(), "start");
        addActionListener(e->c.show("start"));
    }
}
