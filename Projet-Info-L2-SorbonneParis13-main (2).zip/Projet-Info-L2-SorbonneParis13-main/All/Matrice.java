public class Matrice {
    private char nom;
    private int taille;
    private char[][] matrice;
    public Matrice(){
        nom=' ';
        taille=0;
        matrice=null;
    }
    public void setNom(char n){
        nom=n;
    }
    public void setTaille(int t){
        taille=t;
        matrice=new char[taille][taille];
    }
    public void initMatrice(int i, int j, char c){
        matrice[i][j]=c;
    }
    public char getNom(){
        return nom;
    }
    public int getTaille(){
        return taille;
    }
    public char[][] getMatrice(){
        return matrice;
    }
    @Override
    public String toString() {
        String m="";
        m+=nom+" "+taille+'\n';
        for(int i=0; i<matrice.length; i++){
            for(int j=0; j<matrice[0].length; j++)
                m+=matrice[i][j];
            m+='\n';
        }
        return m;
    }
}
