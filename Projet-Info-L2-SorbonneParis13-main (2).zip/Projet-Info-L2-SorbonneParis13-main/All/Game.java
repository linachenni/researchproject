public class Game {
    Level current;
    LevelLector lector;

    public Game(LevelLector level1){
        lector = level1;
        nextLevel();
    }

    public Level level(){
        return current;
    }

    public boolean nextLevel(){
        current = lector.readNextLevel();
        return current != null;
    }
    public int playerL() {
    	return current.playerL;
    }
    public int playerC() {
    	return current.playerC;
    }
    public boolean move(int row, int column) {
    	if(!current.move(row, column)){
            System.out.println("mouvement non autorisé");
            return false;
        }
    	if(current.isFinished()){
            if(!nextLevel())
	            System.exit(0);
        }
        return true;
    }
}
