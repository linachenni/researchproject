import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

public class Cible extends JPanel{
    Color color;
    Niveau niveau;
    public Cible(Color c, Niveau n){
        color=c;
        niveau=n;
    }
    public void paintCible(Graphics arg, int X, int Y){
        Graphics2D arg0=(Graphics2D) arg;
        int zoomX, zoomY;
        int size;
        if(niveau.getBoxMonde()==null){
            zoomX=0;
            zoomY=0;
            size=80;
        }
        else{
            zoomX=niveau.getBoxMonde().zoomX;
            zoomY=niveau.getBoxMonde().zoomX;
            size=niveau.getBoxMonde().getSizeBox();
        }
        
        arg0.setStroke(new BasicStroke(4));
        arg0.setColor(color);
        arg0.drawRect(zoomX+(X*size)+4,zoomY+4+(Y*size),size-10,size-10);
    }
    public Niveau getNiveau(){
        return niveau;
    }
}
