import java.awt.*;
import java.io.InputStream;
import javax.swing.JFrame;

public class GraphicLevel extends Niveau{
    int[][] BM;
    public GraphicLevel(){
        super(new Color(121,62,0));
        matrice=start();
        //BM=bM;
        initBox();
    }
    public void initBox(){
        for(int i=0; i<matrice.length; i++){
            for(int j=0; j<matrice.length; j++){
                if(matrice[i][j]==2)
                    initHeadBox(new Color(184,0,110), j, i, this);
                else if(matrice[i][j]==8)
                    addBox(new Box(Color.yellow,j,i, this));
                else if(matrice[i][j]==9){
                    initBoxMonde(new BoxMonde(new Color(100), Color.blue,j,i, this));
                    addBox(boxMonde);
                }
            }
        }
    }
    @Override
    public void paintComponent(Graphics g){
        for(int i=0; i<matrice.length; i++){
            for(int j=0; j<matrice[0].length; j++){
                System.out.print(matrice[i][j]+" ");
            }
            System.out.println();
        }
        super.paintComponent(g);
        Brique briqueNiveau= new Brique(new Color(255,143,82), this);
        Cible cible=new Cible(new Color(255,143,82), this);
        CibleJoueur cibleJoueur=new CibleJoueur(new Color(255,143,82), this);
        int b=0;
        for(int i=0; i<matrice.length; i++){
            for(int j=0; j<matrice[0].length; j++){
                /*static final int EMPTY = 0;
                static final int WALL = 1;
                static final int PLAYER = 2;
                static final int TARGET = 4;
                static final int BOX = 8; */
                switch(matrice[i][j]){
                    case 1:
                        briqueNiveau.paintBrique(g, j, i);
                        break;
                    case 4 :
                        cible.paintCible(g, j, i);
                        break;
                    case 5:
                        cibleJoueur.paintCibleJoueur(g, j, i);
                        break;
                    case 8 :
                        boxes.get(b).paintBox(g, j, i);
                        b++;
                        break;
                    default:
                        break;
                }
            }
        }
        if(boxMonde!=null)
            boxMonde.paintBoxMonde(g, BM);
        headBox.paintHeadBox(g);
        System.out.println(matrice.length);
    }
    public int[][] start(){
        LevelLector level=null;
        try {
	        InputStream in = Configuration.charge("Levels.txt");
	        level = new LevelLector(in);
	        jeu = new Game(level);
	    } catch (Exception e) {
	        System.err.println("Probleme de demarrage!" + e);
	    }
        return jeu.level().getBoard();
    }
    public static void main(String[] args) {
        JFrame fen = new JFrame("Patrick's Parabox");
        fen.getContentPane().add(new GraphicLevel());
        fen.setSize(new Dimension(720,760));
        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setVisible(true);
    }

}
