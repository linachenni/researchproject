import java.io.InputStream;

public class Sokoban {
	public static void main(String[] args) {
	    try {
	        InputStream in = Configuration.charge("/home/sarr/Bureau/Projet/Projet-Info-L2-SorbonneParis13/Mouvement/src/Global/Levels.txt");
	        LevelLector level = new LevelLector(in);
	        Game jeu = new Game(level);
	        //GraphicInterface.start(jeu);
	    } catch (Exception e) {
	        System.err.println("Probleme de demarrage!" + e);
	    }
	}

}
