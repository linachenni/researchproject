import java.awt.Color;
import java.awt.event.ActionListener;

public class Retour extends Bouton {
    public Retour(Fenêtrage c){
        super("RETOUR", "fonts/chintzy.ttf", new Color(16,48,92), Color.white);
        addActionListener(e->c.first());
    }
    public Retour(ActionListener action){
        super("RETOUR", "fonts/chintzy.ttf", new Color(16,48,92), Color.white);
        addActionListener(action);
    }
}
