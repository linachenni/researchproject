import java.awt.BorderLayout;

import javax.swing.JPanel;

public class Option extends Bouton{
    public Option(Fenêtrage c){
        super("OPTIONS", c);
        c.add(contenu(), "options");
        addActionListener(e->c.show("options"));
    }
    public JPanel contenu(){
        Background back=new Background("BG2.png", "O P T I O N S");
        back.add(new Retour(getCard()), BorderLayout.SOUTH);
        return back;
    }
}

