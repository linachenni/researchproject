import java.awt.Color;
import java.util.*;
import java.awt.Point;
import javax.swing.JPanel;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.Timer;
import javax.swing.event.MouseInputListener;
/*
 * Tous les niveaux hériteront de cette classe
 * 
 * le constructeur prend en paramétre la couleur du background et celle prochainement des murs
 * 
 * on pourra y ajouter d'autres méthodes ou arguments si besoin
 * 
 */

public class Niveau extends JPanel{
    HeadBox headBox;
    BoxMonde boxMonde;
    int[][] matrice;
    ArrayList<int[][]> etatStory= new ArrayList<int[][]>();
    Game jeu;
    ArrayList<Box> boxes=new ArrayList<Box>();
    public Niveau(Color background){
        super();
        System.out.println("cool");
        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent arg0) {
                System.out.println("gagné");
            }
            @Override
            public void focusLost(FocusEvent arg0) {
                System.out.println("perdu");
            }
        });
        setFocusable(true);
        requestFocusInWindow();
        setBackground(background);
    }
    public void cancelStory(){
        if(!headBox.Historique().isEmpty()){
            headBox.cancel();
        }
    }

    public void initGame(Game g){
        jeu = g;
    }
    public void initHeadBox(Color c, int x, int y, Niveau n){
        headBox=new HeadBox(c, x, y, n);
        addListener();
    }
    public void initBoxMonde(BoxMonde B){
        boxMonde=B;
    }
    public Point getCaseCliqué(int x, int y){
        return new Point((int)(x/headBox.getSizeBox()), (int)(y/headBox.getSizeBox()));
    }

    public void suivreLechemin(ArrayList<String> chemin)
    {
        ActionListener déplacementRalenti= new ActionListener() {
            int i=0;
            @Override
            public void actionPerformed(ActionEvent e)
            {   
                switch(chemin.get(i)){
                    case "up": case "Up": case "UP":
                        etatStory.add(copieOf(matrice));
                        jeu.move(-1,0);
                        headBox.moveUp();
                        break;
                    case "down": case "Down": case "DOWN":
                        etatStory.add(copieOf(matrice));
                        jeu.move(1,0);
                        headBox.moveDown();
                        break;
                    case "left": case "Left": case "LEFT":
                        etatStory.add(copieOf(matrice));
                        jeu.move(0,-1);
                        headBox.moveLeft();
                        break;
                    case "right": case "Right": case "RIGHT":
                        etatStory.add(copieOf(matrice));
                        jeu.move(0,1);
                        headBox.moveRight();
                        break;
                    default:
                        System.out.println("mouvement inconnue");
                        break;
                }
                repaint();
                i++;
                if(i<chemin.size()){}
                else ((Timer)e.getSource()).stop();;
            }
        };
        Timer ralentisseur=new Timer(300, déplacementRalenti);
        ralentisseur.start();
    }
    public Box getBox(){
        return null;
    }
    public void addBox(Box b){
        boxes.add(b);
    }
    public BoxMonde getBoxMonde(){
        return boxMonde;
    }
    public HeadBox getHeadBox(){
        return headBox;
    }
    public void addListener(){
        this.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e){
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        etatStory.add(copieOf(matrice));
                        if(!jeu.move(0,-1)){
                            etatStory.remove(etatStory.size()-1);
                            return;
                        }
                        headBox.moveLeft();
                        repaint();
                        break;
                    case KeyEvent.VK_RIGHT:
                        etatStory.add(copieOf(matrice));
                        if(!jeu.move(0,1)){
                            etatStory.remove(etatStory.size()-1);
                            return;
                        }
                        headBox.moveRight();
                        repaint();
                        break;
                    case KeyEvent.VK_DOWN:
                        etatStory.add(copieOf(matrice));
                        if(!jeu.move(1,0)){
                            etatStory.remove(etatStory.size()-1);
                            return;
                        }
                        headBox.moveDown();
                        repaint();
                        break;
                    case KeyEvent.VK_UP:
                        etatStory.add(copieOf(matrice));
                        if(!jeu.move(-1,0)){
                            etatStory.remove(etatStory.size()-1);
                            return;
                        }
                        headBox.moveUp();
                        repaint();
                      break;
                    case KeyEvent.VK_Z:
                        if (e.isControlDown()){
                            if(!etatStory.isEmpty()){
                                cancelStory();
                                copie(matrice, etatStory.get(etatStory.size()-1));
                                jeu.level().setPlayerLAndC(headBox.getY()/headBox.getSizeBox(), headBox.getX()/headBox.getSizeBox());
                                etatStory.remove(etatStory.size()-1);
                                repaint();
                            }
                        }
                        break;
                    case KeyEvent.VK_B:
                        boxMonde.zoom();
                        repaint();
                        break;
                    case KeyEvent.VK_D:
                        boxMonde.unzoom();
                        repaint();
                        break;
                    default:
                        break;
                }
            }
            @Override
            public void keyReleased(KeyEvent e){}
            @Override
            public void keyTyped(KeyEvent e) {}
        });
        addMouseListener(new MouseInputListener() {
            public void mousePressed(MouseEvent arg0){
                Point clic=getCaseCliqué(arg0.getX(), arg0.getY());    
                if(getMatriceBool()!=null){
                    List<String> List=ResolutionAutomatiqueString.trouverCheminPlusCourt(getMatriceBool(), (int)clic.getY(), (int)clic.getX(), headBox.getY()/headBox.getSizeBox(), headBox.getX()/headBox.getSizeBox());
                    if(List!=null && !List.isEmpty())
                        suivreLechemin((ArrayList<String>)List);
                }
            }
            public void mouseDragged(MouseEvent arg0){}
            public void mouseExited(MouseEvent arg0) {}
            public void mouseReleased(MouseEvent arg0) {}
            public void mouseClicked(MouseEvent arg0) {}
            public void mouseEntered(MouseEvent arg0) {}
            public void mouseMoved(MouseEvent arg0) {}
    
        });
    }
    public int[][] copieOf(int[][] m){
        int[][] newM=new int[m.length][m.length];
        for(int i=0; i<m.length; i++){
            for(int j=0; j<m.length; j++){
                newM[i][j]=m[i][j];
            }
        }
        return newM;
    }
    public void copie(int [][] m1, int[][] m2){
        for(int i=0; i<m1.length; i++){
            for(int j=0; j<m1.length; j++){
                m1[i][j]=m2[i][j];
            }
        }
    }
    public Game getJeu(){
        return jeu;
    }
    public int[][] getMatrice(){
        return matrice;
    }
    public boolean[][] getMatriceBool(){
        boolean[][] m= new boolean[matrice.length][matrice.length];
        for(int i=0; i<matrice.length; i++){
            for(int j=0; j<matrice.length; j++){
                switch(matrice[i][j]){
                    case 1: case 8: case 5:
                        m[i][j]=false;
                    break;
                    default:
                        m[i][j]=true;
                    break;
                }
            }
        }
        return m;
    }
}
