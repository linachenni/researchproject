import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Background extends JPanel{
    Image background;
    public Background(String chemin, String Title){
        super();
        Titre titre=new Titre(Title, "chintzy.ttf");
        setLayout(new BorderLayout());
        ImageIcon BG = new ImageIcon(getClass().getResource(chemin));
        background=BG.getImage();
        add(titre, BorderLayout.NORTH);
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
    }
}
