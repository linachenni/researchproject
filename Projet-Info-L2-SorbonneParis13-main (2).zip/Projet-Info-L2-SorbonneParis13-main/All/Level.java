public class Level {
    static final int EMPTY = 0;
    static final int WALL = 1;
    static final int PLAYER = 2;
    static final int TARGET = 4;
    static final int BOX = 8;
    static final int TARGET_PLAYER = 5;
    static final int BOX_MONDE=9;

    private int[][] board;
    int numRow, numColumn;
    String name;
    int playerL, playerC;
    int nomberTarget, nmbBoxOnTarget;

    public Level(){
        board = new int[1][1];
        numRow = numColumn =0;
    }
    public int[][] getBoard(){
        return board;
    }
    public void setBoard(int[][] newM){
        board=newM;
    }
    public void setPlayerLAndC(int x, int y){
        delete(PLAYER, playerL, playerC);
        playerL=x;
        playerC=y;
        addContent(PLAYER, playerL, playerC);
    }

    private int adjust(int c, int i){
        while (c <= i)
            c *= 2;
        return  c;
    }

    private void resizeBoard(int row, int column){
    	int oldRow = board.length;
        int oldColumn = board[0].length;
      

        if((oldRow <= row) || (oldColumn <= column)){
            int newL = adjust(oldRow,row);
            int newC = adjust(oldColumn, column);

            int [][] newBoard = new int [newL][newC];
            for(int i = 0; i < oldRow; i++)
                for(int j = 0; j < oldColumn; j++)
                    newBoard[i][j] = board[i][j];
            board = newBoard;
        }
        if(this.numRow <= row)
            this.numRow = row +1;
        if(this.numColumn <= column)
            this.numColumn = column +1;
    }

    public void fixName(String name){
        this.name = name;
    }


    public void emptyCell(int i, int j){
        board[i][j] = EMPTY;
    }

   private void addContent(int content, int i, int j){
        resizeBoard(i, j);
        board[i][j] |= content;
        if (content == BOX)
        	if(hasTarget(i, j))
        		nmbBoxOnTarget++;
    }


    public void addWall(int i, int j){
        addContent(WALL, i, j);
    }

    public void addPlayer(int i, int j){
        addContent(PLAYER, i, j);
        playerL = i;
        playerC = j;
    }
    
    public void addBox(int i, int j){
        addContent(BOX, i, j);
    }

    public void addTarget(int i, int j){
        addContent(TARGET, i, j);
        nomberTarget++;
        if(hasBox(i, j))
        	nmbBoxOnTarget++;
    }

    public void addTargetPlayer(int i, int j){
        addContent(TARGET_PLAYER, i, j);
        if(hasPlayer(i, j))
            nmbBoxOnTarget++;
    }

    public int lines(){
        return numRow;
    }

    public int columns(){
        return  numColumn;
    }

    public String name(){
        return name;
    }

    public boolean isEmpty(int i, int j){
        return board[i][j] ==EMPTY;
    }

    public boolean hasWall(int i, int j){
        return (board[i][j] & WALL) != 0;
    }

    public boolean hasTarget(int i, int j){
        return (board[i][j] & TARGET) != 0;
    }

    public boolean hasTargetPlayer(int i, int j){
        return (board[i][j] & TARGET_PLAYER) != 0;
    }
    public boolean hasPlayer(int i, int j){
        return (board[i][j] & PLAYER) != 0;
    }

    public boolean hasBox(int i, int j){
        return (board[i][j] & BOX) != 0;
    }
    public int playerL() {
    	return playerL;
    }
    public int playerC() {
    	return playerC;
    }
    /*public boolean move(int dRow, int dColumn) {
        int depRow = playerL + dRow;
        int depColumn = playerC + dColumn;
        
        if(hasBox(depRow, depColumn)) {
            int boxRow = depRow + dRow;
            int boxColumn = depColumn + dColumn;
            if(isFree(boxRow, boxColumn)) {
                // Vérifiez si une deuxième boîte est présente
                int secondBoxRow = boxRow + dRow;
                int secondBoxColumn = boxColumn + dColumn;
                if (hasBox(boxRow, boxColumn) && isFree(secondBoxRow, secondBoxColumn)) {
                    System.out.println("ksfbcdkbcfskhb");
                    // Déplacez les deux boîtes
                    delete(BOX, boxRow, boxColumn);
                    addContent(BOX, secondBoxRow, secondBoxColumn);
                    delete(BOX, depRow, depColumn);
                    addContent(BOX, boxRow, boxColumn);
                } else if (isFree(boxRow, boxColumn)) {
                    // Déplacez la boîte unique
                    delete(BOX, depRow, depColumn);
                    addContent(BOX, boxRow, boxColumn);
                }
            }
        }
        if(isFree(depRow, depColumn)) {
            delete(PLAYER, playerL, playerC);
            playerL = depRow;
            playerC = depColumn;
            addContent(PLAYER, playerL, playerC);
            return true;
        } else {
            return false;
        }
    }*/
    public boolean move(int dRow, int dColumn) {
        int depRow = playerL + dRow;
    	int depColumn = playerC + dColumn;
    	if(hasBox(depRow, depColumn)) {
    		int boxRow = depRow + dRow;
    		int boxColumn = depColumn + dColumn;
            if(hasBox(boxRow, boxColumn)){
                int sndBoxRow = boxRow + dRow;
                int sndBoxColumn = boxColumn + dColumn;
                if(isFree(sndBoxRow, sndBoxColumn)){
                    delete(BOX, boxRow, boxColumn);
                    addContent(BOX, sndBoxRow, sndBoxColumn);
                }
            }
    		if(isFree(boxRow, boxColumn)) {
    			delete(BOX, depRow, depColumn);
    			addContent(BOX, boxRow, boxColumn);
    		}
    	}
    	if(isFree(depRow, depColumn)) {
    		delete(PLAYER, playerL, playerC);
    		playerL = depRow;
    		playerC = depColumn;
    		addContent(PLAYER, playerL, playerC);
    		return true;
    	}else {
    		return false;
    	}
    }
    /*public boolean move(int dRow, int dColumn) {
    	int depRow = playerL + dRow;
    	int depColumn = playerC + dColumn;
    	if(hasBox(depRow, depColumn)) {
    		int boxRow = depRow + dRow;
    		int boxColumn = depColumn + dColumn;
    		if(isFree(boxRow, boxColumn)) {
    			delete(BOX, depRow, depColumn);
    			addContent(BOX, boxRow, boxColumn);
    		}
    	}
    	if(isFree(depRow, depColumn)) {
    		delete(PLAYER, playerL, playerC);
    		playerL = depRow;
    		playerC = depColumn;
    		addContent(PLAYER, playerL, playerC);
    		return true;
    	}else {
    		return false;
    	}
    }*/
    public boolean isFree(int row, int column) {
    	return !hasWall(row, column) && !hasBox(row, column);
    }
    public void delete(int element, int i, int j) {
    	board[i][j] &= ~element;
    	if (element == BOX)
        	if(hasTarget(i, j))
        		nmbBoxOnTarget--;
    }
    public boolean isFinished() {
    	return nmbBoxOnTarget == nomberTarget;
    }
}
