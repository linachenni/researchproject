import java.awt.BorderLayout;

import javax.swing.JPanel;

public class Rules extends Bouton{
    public Rules(Fenêtrage c){
        super("RULES", c);
        c.add(contenuCrédit(), "rules");
        addActionListener(e->c.show("rules"));
    }
    public JPanel contenuCrédit(){
        Background back=new Background("BG2.png", "R U L E S");
        back.add(new Retour(getCard()), BorderLayout.SOUTH);
        return back;
    }
}
